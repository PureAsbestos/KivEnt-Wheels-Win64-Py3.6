from .cymunk import *
from os import path

def get_includes():
    return [path.dirname(__file__)]